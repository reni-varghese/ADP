package com.adp.services;

import java.util.List;

import com.adp.model.Employee;

public interface EmployeeService {

	List<Employee> getAllEmployees();
	Employee getById(int id);
	String addEmployee(Employee employee);
	String updateEmployee(int id,Employee employee);
	String deleteEmployee(int id);
}
