package com.adp.controllers;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.PutExchange;

import com.adp.model.Employee;
import com.adp.services.EmployeeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

	private EmployeeService employeeService;
	
	
	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}

	@GetMapping
	public ResponseEntity<List<Employee>> getAll(){
		
		List<Employee> employees=employeeService.getAllEmployees();
		
		return ResponseEntity.ok(employees);
	}
	@GetMapping("/{id}")
	public ResponseEntity<Employee> getById(@PathVariable int id){
		
		Employee employee=employeeService.getById(id);
		return ResponseEntity.ok(employee);
	}
	@PostMapping
	public ResponseEntity<String> addEmployee(@Valid @RequestBody Employee employee){
		
		String result=employeeService.addEmployee(employee);
		return new ResponseEntity<String>(result,HttpStatus.CREATED);
		
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<String> updateEmployee
		(@PathVariable int id,@RequestBody Employee employee){
		
		String result=employeeService.updateEmployee(id,employee);
		return ResponseEntity.ok(result);
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteEmployee
		(@PathVariable int id){
		
		String result=employeeService.deleteEmployee(id);
		return ResponseEntity.ok(result);
		
	}
	
	
}
