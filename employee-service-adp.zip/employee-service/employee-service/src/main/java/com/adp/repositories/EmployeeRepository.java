package com.adp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.adp.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}
