package com.adp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.adp.exceptions.EmployeeNotFoundException;
import com.adp.model.Employee;
import com.adp.repositories.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeRepository employeeRepository;

	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

	@Override
	public Employee getById(int id) {
		// TODO Auto-generated method stub
		return employeeRepository.findById(id)
				.orElseThrow(()->new EmployeeNotFoundException
						("Employee with id "+id+" not found"));
	}

	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employeeRepository.save(employee);
		return "Employee with name "+employee.getName()+" saved successfully";
	}

	@Override
	public String updateEmployee(int id, Employee employee) {
		Optional<Employee> empOpt=employeeRepository.findById(id);
		if(empOpt.isEmpty()) {
			throw new EmployeeNotFoundException("Employee with id "+id+" not found");
		}
		Employee emp=empOpt.get();
		if(employee.getName()!=null) {
			emp.setName(employee.getName());
		}
		if(employee.getGender()!=null) {
			emp.setGender(employee.getGender());
		}
		if(employee.getAge()!=0) {
			emp.setAge(employee.getAge());
		}
		if(employee.getSalary()!=0) {
			emp.setSalary(employee.getSalary());
		}
		
		employeeRepository.save(emp);
		
		return "Employee updated successfully";
	}

	@Override
	public String deleteEmployee(int id) {
		Optional<Employee> empOpt=employeeRepository.findById(id);
		if(empOpt.isEmpty()) {
			throw new EmployeeNotFoundException("Employee with id "+id+" not found");
		}
		employeeRepository.deleteById(id);
		return "Employee Deleted successfully";
	}

}
