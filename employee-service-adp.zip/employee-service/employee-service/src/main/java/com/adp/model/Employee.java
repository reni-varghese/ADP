package com.adp.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="employee_details")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "myseq")
	@SequenceGenerator(name="myseq",sequenceName = "empseq",
				initialValue = 1,allocationSize = 1)
	private int id;
	@Pattern(regexp = "[A-Za-z\s]{3,}",message = "Employee Name should contain only alphabets")
	private String name;
	@Pattern(regexp = "(Male|Female)",message = "Invalid Gender")
	private String gender;
	@Max(value = 60,message = "Employee age should be between 18 and 60")
	@Min(value = 18,message = "Employee age should be between 18 and 60")
	private int age;
	private double salary;

}
