package org.reni.dao;

import java.util.List;

import org.reni.model.Employee;

public interface EmployeeDao {

	List<Employee> getAll();
}
