package org.reni.service;

import java.util.List;

import org.reni.model.Employee;

public interface EmployeeService {

	List<Employee> getAll();
}
