package com.wipro;

import java.util.InputMismatchException;
import java.util.Scanner;

import javax.xml.xpath.XPathEvaluationResult.XPathResultType;

public class MainApp {
	
	private final int id=20;

	public static  void main(String[] args) {
		try {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Numerator");
		int n1=sc.nextInt();
		System.out.println("Enter Denominator");
		int n2=sc.nextInt();
		int result=n1/n2;
		System.out.println("Result = "+result);
		}
//		catch (InputMismatchException | ArithmeticException  e) {
//			// TODO: handle exception
//		}
		
		catch(InputMismatchException ex) {
			System.out.println("Please Enter a valid number which is can be fit into an integer value");
			
		}
		catch(ArithmeticException ex) {
			System.out.println("Please enter a valud denominator "+ex.getMessage());
		}
		catch(Exception ex) {
			System.out.println("Something went wrong. Try after sometime");
		}
		
		finally {
			System.out.println("Finally block executed");
		}

	}

}
