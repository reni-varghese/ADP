package com.wipro;

public class ChildClass  {

//	@Override
//	public void sayHello() {
//		System.out.println("Hi there!!!");
//	}

	
	
}
