package com.wipro;

public class InvalidDenominatorException extends Exception{

	public InvalidDenominatorException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidDenominatorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
