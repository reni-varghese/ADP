package com.wipro;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import com.wipro.model.Calculator;

public class App {

	public static void main(String[] args)   {
		
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Numerator");
			int n1=sc.nextInt();
			System.out.println("Enter Denominator");
			int n2=sc.nextInt();
			Calculator calc=new Calculator();
			int result;
			try {
				result = calc.divide(n1, n2);
				System.out.println("Result = "+result);
			} catch (InvalidDenominatorException e) {
				System.out.println(e.getMessage());
			}
			
		
		
		

	}

}
