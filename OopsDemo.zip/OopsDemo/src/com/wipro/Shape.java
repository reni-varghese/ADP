package com.wipro;

public abstract  class Shape {
	
	public abstract void  draw();
	public void sayHello() {
		System.out.println("Hello");
	}

}

class Reactangle extends Shape{

	@Override
	public void draw() {
		System.out.println("Rectangle drawn");
		
	}
	
}
class Circle extends Shape{

	@Override
	public void draw() {
		System.out.println("Circle drawn");
		
	}
	
}
class Triangle extends Shape{

	@Override
	public void draw() {
		System.out.println("Triangle drawn");
		
	}
	
}
