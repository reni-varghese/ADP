package com.wipro;

public final  class ParentClass {
	
	
	public  void sayHello() {
		System.out.println("Hello World!");
	}

}
