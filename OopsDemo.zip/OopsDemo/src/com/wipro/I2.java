package com.wipro;

public interface I2 {

	void method2();
}
