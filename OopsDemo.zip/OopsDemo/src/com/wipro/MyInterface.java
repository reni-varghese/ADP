package com.wipro;

public interface MyInterface {
	
	String name="Wipro Technologies";
	
    void draw();
	void greet();
	void sayHello();
	
	default void hello()
	{
		System.out.println("Hello");
	}
	
	static void welcome() {
		System.out.println("Welcome");
	}
	private void myMethod() {
		System.out.println("My Method");
	}

}
