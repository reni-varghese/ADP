package com.wipro.model;

public class FullTimeEmployee extends Employee {

	private double annualSalary;

	public double getAnnualSalary() {
		return annualSalary;
	}

	public void setAnnualSalary(double annualSalary) {
		this.annualSalary = annualSalary;
	}

	

	
	public FullTimeEmployee(int id, String name, String gender, int age, double annualSalary) {
		super(id, name, gender, age);
		this.annualSalary = annualSalary;
	}

	public FullTimeEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public void greet() {
		// TODO Auto-generated method stub
		System.out.println("Hello from FullTime Employee");
	}
	
	
	
	

	

	
	
	
}
