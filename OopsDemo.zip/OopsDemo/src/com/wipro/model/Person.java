package com.wipro.model;

public class Person {

}
