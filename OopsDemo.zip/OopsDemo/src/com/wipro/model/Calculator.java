package com.wipro.model;

import com.wipro.InvalidDenominatorException;

public class Calculator {
	
	public int add(int n1,int n2) {
		return n1+n2;
	}
//	private float add(int n1,int n2) {
//		return n1+n2;
//	}
	
	public int add(int n1,int n2,int n3) {
		return n1+ n2+ n3;
	}
	
	public float add(float n1,float n2) {
		return n1+n2;
	}
	
	public String add(String n1,String n2) {
		return n1+n2;
	}
	
	public double add(int n1,double n2) {
		return n1+n2;
	}
	
	public double add(double n1,int n2) {
		return n1+n2;
	}
	public int divide(int n1,int n2) throws InvalidDenominatorException {
		if(n2<=0) {
			throw new InvalidDenominatorException("Please enter a valid denominator");
		}
		return n1/n2;
	}

}
