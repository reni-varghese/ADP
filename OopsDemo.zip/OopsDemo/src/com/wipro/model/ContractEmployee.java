package com.wipro.model;

public class ContractEmployee extends Employee{

	private double dailyWage;

	public double getDailyWage() {
		return dailyWage;
	}

	public void setDailyWage(double dailyWage) {
		this.dailyWage = dailyWage;
	}

	public ContractEmployee(int id, String name, String gender, int age, double dailyWage) {
		super(id, name, gender, age);
		this.dailyWage = dailyWage;
		
	}

	public ContractEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void greet() {
		// TODO Auto-generated method stub
		System.out.println("Hello from Contract Employee");
	}
	
	
}
