package com.wipro;

public interface I1 {

	void method1();
}
