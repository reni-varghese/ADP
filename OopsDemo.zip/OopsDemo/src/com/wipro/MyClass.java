package com.wipro;

public class MyClass implements MyInterface,I1 {
	
	public static String message;
	
	public static void sayWelcome() {
		System.out.println("Welcome to Java");
	}
;
	public static String getMessage() {
		return message;
	}


	public static void setMessage(String message) {
		MyClass.message = message;
	}


	@Override
	public void draw() {
		System.out.println("Draw method");
		
	}
	
	
	public static void showMessage() {
		System.out.println(message);
	}

	@Override
	public void greet() {
		System.out.println("Greet method");
		
	}

	@Override
	public void sayHello() {
		System.out.println("sayHello Method");
		
	}

	@Override
	public void method1() {
		System.out.println("Method 1 called");
		
	}

}
